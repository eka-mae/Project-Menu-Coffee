# Restaurant Theme

A Bootstrap single page website with menu image grid, modal window popup previews for more details on each menu item and PHP contact form.